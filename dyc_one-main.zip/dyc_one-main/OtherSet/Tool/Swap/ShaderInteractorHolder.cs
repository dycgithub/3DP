using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 
[ExecuteInEditMode]
public class ShaderInteractorHolder : MonoBehaviour
{
    ShaderInteractorPosition[] interactors;
    Vector4[] positions;
    float[] radiuses;
    Vector4[] boxBounds;
    Vector4[] rotations;
    float[] textureIndex;
 
    [Range(0, 1)]
    public float shapeCutoff;
    [Range(0, 1)]
    public float shapeSmoothness = 0.1f;
    // Start is called before the first frame update
    void Start()
    {
        FindInteractors();
    }
    private void OnEnable()
    {
        FindInteractors();
    }
 
 
    void FindInteractors()
    {
        interactors = FindObjectsByType<ShaderInteractorPosition>(FindObjectsSortMode.None);
        positions = new Vector4[100];
        radiuses = new float[100];
        boxBounds = new Vector4[100];
        rotations = new Vector4[100];
        textureIndex = new float[100];
    }
 
    // Update is called once per frame
    void Update()
    {
        FindInteractors();
        for (int i = 0; i < interactors.Length; i++)
        {
            positions[i] = interactors[i].transform.position;
            radiuses[i] = interactors[i].radius;
            boxBounds[i] = interactors[i].transform.localScale;
            rotations[i] = interactors[i].transform.eulerAngles;
            textureIndex[i] = interactors[i].textureIndex;
        }
        Shader.SetGlobalVectorArray("_ShaderInteractorsPositions", positions);
        Shader.SetGlobalFloatArray("_ShaderInteractorsRadiuses", radiuses);
        Shader.SetGlobalFloatArray("_ShaderInteractorsIndices", textureIndex);
        Shader.SetGlobalVectorArray("_ShaderInteractorsBoxBounds", boxBounds);
        Shader.SetGlobalVectorArray("_ShaderInteractorRotation", rotations);
 
        Shader.SetGlobalFloat("_ShapeCutoff", shapeCutoff);
        Shader.SetGlobalFloat("_ShapeSmoothness", shapeSmoothness);
 
    }
}