using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

public class Rope : MonoBehaviour
{
    public int particlesNum;//粒子总数
    public float particleStartingSpacing;//初始间距
    
    
    private List<RopeParticle> particlesList = new List<RopeParticle>();//存储粒子
    private Vector3 Gravity = new Vector3(0, -9.8f, 0);//重力加速度

    public float springStiffness = 1000f;//刚度
    public float damping = 0.5f;//阻尼系数,如果不添加阻尼绳子会一直抖动,因为能量无法释放
    public float mass = 1f;//质量
    private void Start()
    {
        var offset = new Vector3(particleStartingSpacing, 0, 0);
        for (int i = 0; i < particlesNum; i++)
        {
            if (i == 0)
            {
                particlesList.Add(new RopeParticle(transform.position));
            }
            else
            {
                particlesList.Add(new RopeParticle(particlesList[i-1].position+i * offset));
                
            }
        }
    }

    private void FixedUpdate()
    {
        for (int i = 1; i < particlesNum; i++)
        {
            Vector3 displacement=particlesList[i-1].position-particlesList[i].position;//位移
            float variablesOffset = displacement.magnitude - particleStartingSpacing;
            Vector3 springForce = springStiffness * variablesOffset * displacement.normalized;
            particlesList[i].force += springForce;
            particlesList[i - 1].force -= springForce;
            particlesList[i].force += Gravity*mass;
            particlesList[i].force -= damping * particlesList[i].velocity;//阻尼
        }
        particlesList[0].position = transform.position;//锚点位置不变
        for (int i = 1; i < particlesNum; i++)
        {
            Vector3 acceleration = particlesList[i].force / mass;
            particlesList[i].velocity += acceleration * Time.fixedDeltaTime;
            particlesList[i].position += particlesList[i].velocity * Time.fixedDeltaTime;
            particlesList[i].force = Vector3.zero;
        }
    }

    public class RopeParticle
    {
        public Vector3 position;
        public Vector3 velocity;
        public Vector3 force;
        public RopeParticle(Vector3 pos)//构造函数
        {
            this.position = pos;
        }
    }

    private void OnDrawGizmos()
    {
        if (particlesList == null || particlesList.Count < 2)
            return;
        Gizmos.color = Color.green;
        for (int i = 0; i < particlesNum; i++)
        {
            Gizmos.DrawSphere(particlesList[i].position, 0.05f);
            if (i == 0)
            {
                continue;
            }
            Gizmos.DrawLine(particlesList[i - 1].position, particlesList[i].position);
        }
    }
}
