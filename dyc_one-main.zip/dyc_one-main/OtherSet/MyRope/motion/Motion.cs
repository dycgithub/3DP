using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;

public class Motion : MonoBehaviour
{
    InputDevice deviceLeft;//左手柄
    InputDevice deviceRight;//右手柄
    private void Start()
    {
        deviceLeft = InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
        deviceRight = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
    }
    
    
    
    
    
    
    
    
}
