using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MySceneManagerAndEffectControl : MonoBehaviour
{
    public float changeSpeed = 1;
    public float changeTime=180;
    private float changeStart = 0;
    [NonSerialized]public string currentSceneName;
    [NonSerialized]public string nextSceneName;
    public ShaderInteractorPosition shaderInteractorPosition;
    

    public void Scan()
    {
        if (currentSceneName != nextSceneName)
        {
            SceneManager.LoadScene(nextSceneName, LoadSceneMode.Additive);
            StartCoroutine(ScanCoroutine());
        }
        
    }

    private IEnumerator ScanCoroutine()
    {
        shaderInteractorPosition.radius = 30;
        while (changeStart < changeTime)
        {
            changeStart += changeSpeed;
            
            yield return new WaitForSecondsRealtime(.01f);
        }

        while (shaderInteractorPosition.radius>0.001f)
        {
            shaderInteractorPosition.radius -= changeSpeed*0.05f;
            yield return new WaitForSecondsRealtime(.01f);
        }
        changeStart = 0;
        if (currentSceneName!= null)
        {
            shaderInteractorPosition.radius = 0;
            SceneManager.UnloadSceneAsync(currentSceneName);
        }
        currentSceneName= nextSceneName;
    }
    
    
    
}
