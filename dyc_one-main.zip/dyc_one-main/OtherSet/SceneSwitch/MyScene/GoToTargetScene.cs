using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoToTargetScene : MonoBehaviour
{
    public MySceneManagerAndEffectControl M;
    public String targetSceneName;
    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("GoToTargetScene");
        M.nextSceneName = targetSceneName;
        M.Scan();
    }
}
