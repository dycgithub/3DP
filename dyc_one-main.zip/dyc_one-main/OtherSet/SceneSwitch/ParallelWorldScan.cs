using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ParallelWorldScan : PostEffectsBase
{
    public ParallelWorldChange parallel;
    public string SceneName;
    public float startScanRange = 0;
    public float maxScanRange = 20;
    public float scanWidth = 3;
    public float scanSpeed = 1;
    public Color scanColor = Color.blue;

    public bool isInScan { get; private set; }
    private Vector3 centerPos;
    public float scanRadius;
    public Transform startPoint;

    
    public ShaderInteractorHolder shaderInteractorHolder;
    void OnEnable()
    {
        scanRadius = startScanRange;
        Cam.depthTextureMode = DepthTextureMode.Depth;
    }



    protected override void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (Material != null && isInScan)
        {
            
            Material.SetVector("_ScanCenterPos", centerPos);
            Material.SetFloat("_ScanRadius", scanRadius);
            Material.SetFloat("_ScanWidth", scanWidth);
            Material.SetColor("_ScanColor", scanColor);

            RaycastCornerBlit(source, destination, Material);
        }
        else
        {
            Graphics.Blit(source, destination);
        }
    }

    void RaycastCornerBlit(RenderTexture source, RenderTexture dest, Material mat)
    {
        float CameraFar = Cam.farClipPlane;
        float CameraFov = Cam.fieldOfView;
        float CameraAspect = Cam.aspect;

        float fovWHalf = CameraFov * 0.5f;

        Vector3 toRight = Cam.transform.right * Mathf.Tan(fovWHalf * Mathf.Deg2Rad) * CameraAspect;
        Vector3 toTop = Cam.transform.up * Mathf.Tan(fovWHalf * Mathf.Deg2Rad);

        Vector3 topLeft = (Cam.transform.forward - toRight + toTop);
        float CameraScale = topLeft.magnitude * CameraFar;

        topLeft.Normalize();
        topLeft *= CameraScale;

        Vector3 topRight = (Cam.transform.forward + toRight + toTop);
        topRight.Normalize();
        topRight *= CameraScale;

        Vector3 bottomRight = (Cam.transform.forward + toRight - toTop);
        bottomRight.Normalize();
        bottomRight *= CameraScale;

        Vector3 bottomLeft = (Cam.transform.forward - toRight - toTop);
        bottomLeft.Normalize();
        bottomLeft *= CameraScale;

        RenderTexture.active = dest;

        mat.SetTexture("_MainTex", source);

        GL.PushMatrix();
        GL.LoadOrtho();

        mat.SetPass(0);

        GL.Begin(GL.QUADS);

        GL.MultiTexCoord2(0, 0.0f, 0.0f);
        GL.MultiTexCoord(1, bottomLeft);
        GL.Vertex3(0.0f, 0.0f, 0.0f);

        GL.MultiTexCoord2(0, 1.0f, 0.0f);
        GL.MultiTexCoord(1, bottomRight);
        GL.Vertex3(1.0f, 0.0f, 0.0f);

        GL.MultiTexCoord2(0, 1.0f, 1.0f);
        GL.MultiTexCoord(1, topRight);
        GL.Vertex3(1.0f, 1.0f, 0.0f);

        GL.MultiTexCoord2(0, 0.0f, 1.0f);
        GL.MultiTexCoord(1, topLeft);
        GL.Vertex3(0.0f, 1.0f, 0.0f);

        GL.End();
        GL.PopMatrix();
    }

    public void Scan(Vector3 point, string nextSceneName)
    {
        SceneManager.LoadScene(nextSceneName, LoadSceneMode.Additive);
        if (startPoint)
        {
            centerPos = startPoint.position;
        }
        else
        {
            centerPos = point;
        }
        
        StartCoroutine(ScanCoroutine());
    }

    private IEnumerator ScanCoroutine()
    {
        isInScan = true;
        while (scanRadius < maxScanRange)
        {
            scanRadius += scanSpeed;
            yield return new WaitForSecondsRealtime(.01f);
        }
        scanRadius = startScanRange;
        isInScan = false;
        parallel.SwapCameras();
        SceneManager.UnloadSceneAsync(SceneName);
    }
}
