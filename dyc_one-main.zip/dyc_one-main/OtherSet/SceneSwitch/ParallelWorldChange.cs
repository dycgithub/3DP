using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ParallelWorldChange : MonoBehaviour
{
    public ParallelWorldScan activeCamera;
    public ParallelWorldScan hideCamera;

    private void Start()
    {
        RenderTexture rt = new RenderTexture(Screen.width, Screen.height, 24);
        activeCamera.Material.SetTexture("_NewTex", rt);
        hideCamera.Cam.targetTexture = rt;

        SceneManager.LoadScene(activeCamera.SceneName, LoadSceneMode.Additive);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0) && !activeCamera.isInScan)
        {
            Debug.Log("Scan");
            Ray ray = activeCamera.Cam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                activeCamera.Scan(hit.point, hideCamera.SceneName);
            }
        }
    }

    public void SwapCameras()
    {
        //hideCamera.Camera.targetTexture.Release();
        activeCamera.Cam.targetTexture = hideCamera.Cam.targetTexture;
        hideCamera.Cam.targetTexture = null;

        ParallelWorldScan swapCamera = activeCamera;
        activeCamera = hideCamera;
        hideCamera = swapCamera;

        activeCamera.Material.SetTexture("_NewTex", hideCamera.Cam.targetTexture);
    }
}
