using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractionOutline : MonoBehaviour
{
    private OutlineControl m_outline_control;//前一个物体
   
    void Update()
    {
        var ray=Camera.main.ScreenPointToRay(Input.mousePosition);
        if(Physics.Raycast(ray,out RaycastHit hitInfo))
        {
            m_outline_control?.SetOutlineEnable( false);
            var outline= hitInfo.transform.GetComponentInChildren<OutlineControl>();
            if (outline)
            {
                outline.SetOutlineEnable(true);
            }
            m_outline_control = outline;
        }
        else
        {
            m_outline_control?.SetOutlineEnable( false);
            m_outline_control = null;
        }
    }
}
