using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 可读性技巧,在位运算中,在unity中修改layer,可以将位运算修改layer用单例的变量代替
/// </summary>
[RequireComponent(typeof(Renderer))]
public class OutlineControl : MonoBehaviour
{

   
   [SerializeField][ColorUsage(true,true)]private Color m_outlineColor;
   
   private Renderer m_renderer;

   private void Awake()
   {
      m_renderer = GetComponent<Renderer>();
   }

   public void SetOutlineEnable(bool switchOutline)//硬编码
   {
      if(switchOutline)
      {
         m_renderer.renderingLayerMask |= (OutLineManager.OUTLINE_LAYER_MASK);
         OutLineManager.instance.SetOutlineColour(m_outlineColor);
      }
      else
      {
         m_renderer.renderingLayerMask &= ~(OutLineManager.OUTLINE_LAYER_MASK);
      }
   }
}
