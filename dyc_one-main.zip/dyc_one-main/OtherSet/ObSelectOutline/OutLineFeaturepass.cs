using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
/// <summary>
/// 框架
/// </summary>
public class OutLineFeaturepass : ScriptableRendererFeature
{
    
    class OutLinePass : ScriptableRenderPass
    {
        private static readonly List<ShaderTagId> s_shaderTagIds=new List<ShaderTagId>()
        {
            new ShaderTagId("UniversalForward"),
            new ShaderTagId("SRPDefaultUnlit"),
            new ShaderTagId("UniversalForwardOnly")
        };

        private static readonly int s_ShaderProp_OutlineMask = Shader.PropertyToID("_OutlineMask");//获取shader的变量
        
        private readonly Material m_outlineMaterial;//在构造函数赋值,所以只读
        private readonly FilteringSettings m_filteringSettings;
        private readonly MaterialPropertyBlock m_propertyBlock;
        
        private RTHandle m_OutlineMaskRT;//处理渲染目标
        public OutLinePass(Material outline_mat)
        {
            renderPassEvent = RenderPassEvent.BeforeRenderingPostProcessing;
            
            m_filteringSettings = new FilteringSettings(RenderQueueRange.all,renderingLayerMask:
                OutLineManager.OUTLINE_LAYER_MASK);//描边不关心是否透明
            m_propertyBlock = new MaterialPropertyBlock();
            m_outlineMaterial = outline_mat;
        }

        public void Dispose()
        {
            m_OutlineMaskRT?.Release();
            m_OutlineMaskRT = null;
        }
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
        {
            ResetTarget();
            var desc=renderingData.cameraData.cameraTargetDescriptor;
            desc.msaaSamples = 1;
            desc.depthBufferBits = 0;
            desc.colorFormat = RenderTextureFormat.ARGB32;
            RenderingUtils.ReAllocateIfNeeded(ref m_OutlineMaskRT,desc,name:"_OutlineMaskRT");
        }

        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            var cmd=CommandBufferPool.Get("Outline Command");
            //绘制RT
            cmd.SetRenderTarget(m_OutlineMaskRT);
            cmd.ClearRenderTarget(true,true,Color.clear);
            
            var drawingSettings = CreateDrawingSettings(s_shaderTagIds, ref renderingData, SortingCriteria.None);
            var rendererListParams=new RendererListParams(renderingData.cullResults,drawingSettings,m_filteringSettings);
            var list = context.CreateRendererList(ref rendererListParams);
            cmd.DrawRendererList(list);
            //绘制oulineshader
            cmd.SetRenderTarget(renderingData.cameraData.renderer.cameraColorTargetHandle);//绘制目标设为摄影机而不是RT
            m_propertyBlock.SetTexture(s_ShaderProp_OutlineMask,m_OutlineMaskRT);//将上方绘制的RT给到摄影机
            cmd.DrawProcedural(Matrix4x4.identity,m_outlineMaterial,0,MeshTopology.Triangles,3,1,m_propertyBlock);
            
            context.ExecuteCommandBuffer(cmd);
            cmd.Clear();
            CommandBufferPool.Release(cmd);
        }
        
    }

    
    [SerializeField] private Material m_OutlineMaterial;
    private bool IsMaterialValid => m_OutlineMaterial && m_OutlineMaterial.shader && m_OutlineMaterial.shader.isSupported;
    OutLinePass m_outLinePass;


    public override void Create()
    {
        if (!IsMaterialValid)
        {
            return;
        }
        m_outLinePass = new OutLinePass(m_OutlineMaterial);
        
    }

    
    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        if (!IsMaterialValid)
        {
            return;
        }
        renderer.EnqueuePass(m_outLinePass);
    }
    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        m_outLinePass?.Dispose();
    }
}


