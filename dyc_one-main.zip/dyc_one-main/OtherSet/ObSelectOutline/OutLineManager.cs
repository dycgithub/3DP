using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OutLineManager : MonoBehaviour
{
    private const int OUTLINE_LAYER_INDEX = 1;
    public const uint OUTLINE_LAYER_MASK = 1<<OUTLINE_LAYER_INDEX;
    public static OutLineManager instance{get;private set;}
    private static readonly int s_ShaderProp_OutlineColor= Shader.PropertyToID("_OutlineColor");
    [SerializeField]private Material m_outlineMaterial;
    private void Awake()
    {
        instance=this;
    }

    public void SetOutlineColour(Color color)
    {
        m_outlineMaterial.SetColor(s_ShaderProp_OutlineColor,color);
    }
}
