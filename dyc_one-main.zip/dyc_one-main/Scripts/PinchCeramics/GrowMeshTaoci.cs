using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]
public class GrowMeshTaoci : MonoBehaviour
{
    [Header("网格精度")]
    public int Details = 80;
    public int LayerCount = 40;
    public float LayerHeight = 0.05f;
    public float Radius = 1f;
    public float Thickness = 0.1f;
    public float MinRadius = 0.5f;
    public float MaxRadius = 1.5f;

    [Header("塑形参数")]
    public float InfluenceLayer = 20f;
    public float TouchPower = 0.005f;
    public Material Potteing;
    public LayerMask PotteryLayerMask;

    private MeshFilter meshFilter;
    private MeshRenderer meshRenderer;
    private Mesh mesh;
    private Mesh theMesh;               // 真正被修改的网格
    private int SplitIndex;             // 外壁/内壁分界顶点索引
    private float SqrMaxOuterRadius;
    private float SqrMinOuterRadius;
    private float SqrMaxInnerRadius;
    private float SqrMinInnerRadius;

    private Vector3 targetWorldPos;
    private bool isShaping = false;
    private Vector3 lastScreenPos;

    void OnValidate()
    {
        if (Thickness >= Radius) Thickness = Radius - 0.01f;
        if (MinRadius >= MaxRadius) MinRadius = MaxRadius - 0.01f;
    }

    void Start()
    {
        SqrMaxOuterRadius = MaxRadius * MaxRadius;
        SqrMinOuterRadius = MinRadius * MinRadius;
        SqrMaxInnerRadius = (MaxRadius - Thickness) * (MaxRadius - Thickness);
        SqrMinInnerRadius = (MinRadius - Thickness) * (MinRadius - Thickness);
        GenerateMesh();
    }

    private void GenerateMesh()
    {
        meshFilter = GetComponent<MeshFilter>();
        if (meshFilter == null) meshFilter = gameObject.AddComponent<MeshFilter>();

        meshRenderer = GetComponent<MeshRenderer>();
        if (meshRenderer == null) meshRenderer = gameObject.AddComponent<MeshRenderer>();
        if (Potteing != null) meshRenderer.material = Potteing;

        // 销毁旧 Mesh，防止内存泄漏
        if (mesh != null)
        {
            if (Application.isPlaying) Destroy(mesh);
            else DestroyImmediate(mesh);
        }

        mesh = new Mesh { name = "PotteryMesh" };
        List<Vector3> vertices = new List<Vector3>();
        List<int> triangles = new List<int>();
        List<Vector2> uvs = new List<Vector2>();

        float deltaAngle = 2f * Mathf.PI / Details;

        CreateBottom(deltaAngle, vertices, triangles, uvs);
        CreateOuter(deltaAngle, vertices, triangles, uvs);
        CreateTop(deltaAngle, vertices, triangles, uvs);
        CreateInner(deltaAngle, vertices, triangles, uvs);
        CreateInnerBottom(deltaAngle, vertices, triangles, uvs);

        mesh.SetVertices(vertices);
        mesh.SetTriangles(triangles, 0);
        mesh.SetUVs(0, uvs);
        mesh.RecalculateNormals();
        mesh.RecalculateTangents();

        meshFilter.mesh = mesh;

        // 关键修复：赋值给 theMesh 和 SplitIndex
        theMesh = mesh;
        SplitIndex = 1 + Details + (LayerCount + 1) * (Details + 1);
    }

    #region 网格创建函数
    void CreateBottom(float delta, List<Vector3> v, List<int> t, List<Vector2> u)
    {
        v.Add(Vector3.zero);
        u.Add(new Vector2(0.25f, 0.25f));
        for (int i = 0; i < Details; i++)
        {
            float ang = i * delta;
            Vector3 vv = new Vector3(Radius * Mathf.Cos(ang), 0, Radius * Mathf.Sin(ang));
            v.Add(vv);
            t.Add(i + 1);
            t.Add((i == Details - 1) ? 1 : i + 2);
            t.Add(0);
            u.Add(new Vector2(0.25f + 0.25f * Mathf.Cos(ang), 0.25f + 0.25f * Mathf.Sin(ang)));
        }
    }

    void CreateOuter(float delta, List<Vector3> v, List<int> t, List<Vector2> u)
    {
        for (int layer = 0; layer <= LayerCount; layer++)
        {
            float y = layer * LayerHeight;
            int baseV = v.Count;
            float vv = ((float)layer / LayerCount) * 0.4f + 0.5f;
            for (int i = 0; i <= Details; i++)
            {
                float ang = (i == Details) ? 0 : i * delta;
                v.Add(new Vector3(Radius * Mathf.Cos(ang), y, Radius * Mathf.Sin(ang)));
                if (layer > 0 && i < Details)
                {
                    int a = baseV + i, b = baseV + i + 1, c = baseV - Details - 1 + i, d = baseV - Details + i;
                    t.Add(a); t.Add(b); t.Add(c);
                    t.Add(c); t.Add(b); t.Add(d);
                }
                u.Add(new Vector2((float)i / Details, vv));
            }
        }
    }

    void CreateTop(float delta, List<Vector3> v, List<int> t, List<Vector2> u)
    {
        float inner = Radius - Thickness;
        for (int h = 0; h < 2; h++)
        {
            float y = (LayerCount - h) * LayerHeight;
            int baseV = v.Count;
            float vv = 0.95f + h * 0.05f;
            for (int i = 0; i <= Details; i++)
            {
                float ang = (i == Details) ? 0 : i * delta;
                v.Add(new Vector3(inner * Mathf.Cos(ang), y, inner * Mathf.Sin(ang)));
                if (i < Details)
                {
                    int a = baseV + i, b = baseV + i + 1, c = baseV - Details - 1 + i, d = baseV - Details + i;
                    t.Add(a); t.Add(b); t.Add(c);
                    t.Add(c); t.Add(b); t.Add(d);
                }
                u.Add(new Vector2((float)i / Details, vv));
            }
        }
    }

    void CreateInner(float delta, List<Vector3> v, List<int> t, List<Vector2> u)
    {
        float inner = Radius - Thickness;
        int count = LayerCount - 1;
        for (int layer = 0; layer < count; layer++)
        {
            float y = (LayerCount - layer - 1) * LayerHeight;
            int baseV = v.Count;
            float vv = 0.5f - ((float)layer / count) * 0.5f;
            for (int i = 0; i <= Details; i++)
            {
                float ang = (i == Details) ? 0 : i * delta;
                v.Add(new Vector3(inner * Mathf.Cos(ang), y, inner * Mathf.Sin(ang)));
                if (layer > 0 && i < Details)
                {
                    int a = baseV + i, b = baseV + i + 1, c = baseV - Details - 1 + i, d = baseV - Details + i;
                    t.Add(a); t.Add(b); t.Add(c);
                    t.Add(c); t.Add(b); t.Add(d);
                }
                u.Add(new Vector2((float)i / Details * 0.5f + 0.5f, vv));
            }
        }
    }

    void CreateInnerBottom(float delta, List<Vector3> v, List<int> t, List<Vector2> u)
    {
        float inner = Radius - Thickness;
        int baseV = v.Count;
        for (int i = 0; i < Details; i++)
        {
            float ang = i * delta;
            v.Add(new Vector3(inner * Mathf.Cos(ang), LayerHeight, inner * Mathf.Sin(ang)));
            t.Add(baseV + Details);
            t.Add((i == Details - 1) ? baseV : baseV + i + 1);
            t.Add(baseV + i);
            u.Add(new Vector2(0.75f + 0.25f * Mathf.Cos(ang), 0.25f + 0.25f * Mathf.Sin(ang)));
        }
        v.Add(new Vector3(0, LayerHeight, 0));
        u.Add(new Vector2(0.75f, 0.25f));
    }
    #endregion

    // public void mold(bool start)
    // {
    //     if (start)
    //     {
    //         lastScreenPos=
    //     }
    // }
    void Update()
    { 
        if (Input.touchCount == 1)
        {
            Touch tc = Input.GetTouch(0);
            if (tc.phase == TouchPhase.Began)
            {
                if (Physics.Raycast(Camera.main.ScreenPointToRay(tc.position), out RaycastHit hit, 1000f, PotteryLayerMask))
                { targetWorldPos = hit.point; isShaping = true; }
                else isShaping = false;
            }
            else if (isShaping && tc.phase == TouchPhase.Moved) ShapeIt(tc.deltaPosition);
            else if (tc.phase == TouchPhase.Ended) isShaping = false;
        }
        else
        {
            if (Input.GetMouseButtonDown(0))
            {
                lastScreenPos = Input.mousePosition;
                if (Physics.Raycast(Camera.main.ScreenPointToRay(lastScreenPos), out RaycastHit hit, 1000f, PotteryLayerMask))
                { targetWorldPos = hit.point; isShaping = true; }
                else isShaping = false;
            }
            else if (isShaping && Input.GetMouseButton(0))
            {
                Vector3 curr = Input.mousePosition;
                ShapeIt(curr - lastScreenPos);
                lastScreenPos = curr;
            }
            else if (Input.GetMouseButtonUp(0)) isShaping = false;
        }
    }

    void ShapeIt(Vector3 delta)
    {
        bool h = false, v = false;
        float dirRate = 0, scale = 0;
        if (delta.x > 0.01f) { dirRate = IsInRight() ? 1f : -1f; h = true; }
        else if (delta.x < -0.01f) { dirRate = IsInRight() ? -1f : 1f; h = true; }
        if (delta.y > 0.02f) { scale = 0.001f; v = true; }
        else if (delta.y < -0.02f) { scale = -0.001f; v = true; }

        if (h)
        {
            Vector3 targetLocal = transform.InverseTransformPoint(targetWorldPos);
            Vector3[] verts = theMesh.vertices;
            float range = InfluenceLayer * LayerHeight;
            for (int i = 1; i < verts.Length; i++)
            {
                float max, min;
                if (i < SplitIndex) { max = SqrMaxOuterRadius; min = SqrMinOuterRadius; }
                else { max = SqrMaxInnerRadius; min = SqrMinInnerRadius; }
                float dis = Mathf.Abs(targetLocal.y - verts[i].y);
                if (dis < range)
                {
                    Vector3 dir = verts[i]; dir.y = 0;
                    if ((dirRate > 0 && dir.sqrMagnitude < max) || (dirRate < 0 && dir.sqrMagnitude > min))
                        verts[i] += dir.normalized * dirRate * TouchPower * (1f - dis / range);
                }
            }
            theMesh.vertices = verts;
            theMesh.RecalculateBounds();
            theMesh.RecalculateNormals();
            SmoothNormals();
        }
        //垂直缩放暂时禁用，避免破坏已调整顶点
        // if (v)
        // {
        //     Vector3 sc = transform.localScale;
        //     sc.y = Mathf.Clamp(sc.y + scale, 0.5f, 1.5f);
        //     transform.localScale = sc;
        // }
    }

    bool IsInRight()
    {
        Transform cam = Camera.main.transform;
        Vector3 target = cam.InverseTransformPoint(targetWorldPos);
        Vector3 pottery = cam.InverseTransformPoint(transform.position);
        return target.x > pottery.x;
    }

    void SmoothNormals()
    {
        if (theMesh == null) return;
        Vector3[] normals = theMesh.normals;
        int step = Details + 1;
        int start = step;
        int end = start + (LayerCount + 3) * step;
        for (int i = start; i < end; i += step)
        {
            try
            {
                int i1 = i, i2 = i + Details;
                if (i1 >= normals.Length || i2 >= normals.Length) continue;
                Vector3 n = ((normals[i1] + normals[i2]) * 0.5f).normalized;
                normals[i1] = n; normals[i2] = n;
            }
            catch { /* 忽略越界 */ }
        }
        theMesh.normals = normals;
    }
}