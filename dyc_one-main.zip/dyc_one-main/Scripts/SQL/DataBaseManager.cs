using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using UnityEngine;
using Npgsql;
using XCharts.Runtime;
using Random = System.Random;

/// <summary> 表格名字_X轴对应列_Y轴对应列;
/// 陈子越:
/// 王佳存:
/// 武文博:
/// 赵良玉:
/// 甄朋策:
/// 修改数据表名称,根据名称确定需要那列数据
/// </summary>
public class DataBaseManager : MonoBehaviour
{
    private string connectionString;

    [Header("Database Configuration")]
    
    [SerializeField][Tooltip("要连接的主机")]private string host = "localhost";
    [SerializeField][Tooltip("端口号")]private int port = 5432;
    [SerializeField][Tooltip("数据库名称")]private string database = "your_database";
    [SerializeField][Tooltip("账号")]private string username = "your_username";
    [SerializeField][Tooltip("密码")]private string password = "your_password";

    [Header("配置数据库的表与对应chart")]
    [SerializeField]
    private List<ObjectTableMapping> XCharts = new List<ObjectTableMapping>();
    
    [NonSerialized]public string switchTableName;
    
    void Start()
    {
        connectionString = $"Host={host};Port={port};Username={username};Password={password};Database={database};";
        Debug.Log(connectionString);
        SetDataBaseAndXChartsComponent();
    }

    public void SwitchDBFrom()
    {
        foreach (var x in XCharts)
        {
            x.tableName = switchTableName;
        }
        
        RefreshAllChart();
        SetDataBaseAndXChartsComponent();
    }
    private void RefreshAllChart()
    {
        BaseChart[] charts=FindObjectsByType<BaseChart>(FindObjectsSortMode.None);
        foreach (var VARIABLE in charts)
        {
            
            VARIABLE.ClearData();
        }
    }
    private void SetDataBaseAndXChartsComponent()
    {
        GameObject[] XChartObj=new GameObject[XCharts.Count];//chart对象
        String[] table=new String[XCharts.Count];//表名称
        BaseChart[] chartsComponent=new BaseChart[XCharts.Count];//chart组件
        
        for (int i = 0; i < XCharts.Count; i++)
        {
            XChartObj[i] = XCharts[i].chartObject;
            table[i] = XCharts[i].tableName;

            if (XChartObj[i].TryGetComponent<BaseChart>(out BaseChart chart))
            {
                chartsComponent[i] = chart;
                // 示例：检查并使用特定子类的功能
                if (chart is LineChart lineChart)
                {
                    
                    List<object> ColumnDatax = GetColumnData(table[i], 0);
                    var xAxis = chart.EnsureChartComponent<XAxis>();
                    xAxis.data = ColumnDatax.ConvertAll(item => item.ToString());
                    
                    List<object> ColumnDatay = GetColumnData(table[i], 1);
                    var serie = chart.GetSerie<Line>();
                    List<double> doubleList = ColumnDatay.Select(item => Convert.ToDouble(item)).ToList();
                    foreach (var d in doubleList)
                    {
                        serie.AddData(d);
                    }
                    chart.EnsureChartComponent<Title>().text = table[i]+"LineChart";

                }
                else if (chart is BarChart barChart)
                {
                    List<object> ColumnDatax = GetColumnData(table[i], 0);
                    var xAxis = chart.EnsureChartComponent<XAxis>();
                    xAxis.data = ColumnDatax.ConvertAll(item => item.ToString());
                    
                    List<object> ColumnDatay = GetColumnData(table[i], 1);
                    var serie = chart.GetSerie<Bar>();
                    List<double> doubleList = ColumnDatay.Select(item => Convert.ToDouble(item)).ToList();
                    foreach (var d in doubleList)
                    {
                        serie.AddData(d);
                    }
                    chart.EnsureChartComponent<Title>().text = table[i]+"BarChart";
                }
                else if (chart is PieChart pieChart)
                {
                    //获取两列数据
                    List<object> ColumnDatax = GetColumnData(table[i], 0);//名字
                    List<object> ColumnDatay = GetColumnData(table[i], 1);//对应数据
                    //将数据格式转换
                    List<string> nameString=ColumnDatax.ConvertAll(item => item.ToString());
                    List<double> doubleList = ColumnDatay.Select(item => Convert.ToDouble(item)).ToList();
                    //获取serie
                    var serie = chart.GetSerie<Pie>();
                    //添加数据到合适维度
                    for (int pie = 0; pie < nameString.Count; pie++)
                    {
                        serie.AddXYData((double)pie,doubleList[pie],nameString[pie],pie.ToString());
                    }
                    chart.EnsureChartComponent<Title>().text = table[i]+"PieChart";
                    

                }
                else if (chart is RadarChart radarChart)
                {
                    //获取两列数据
                    List<object> ColumnDatax = GetColumnData(table[i], 0);//名字
                    List<object> ColumnDatay = GetColumnData(table[i], 1);//对应数据
                    //将数据格式转换
                    List<string> nameString=ColumnDatax.ConvertAll(item => item.ToString());
                    List<double> doubleList = ColumnDatay.Select(item => Convert.ToDouble(item)).ToList();
                    //获取serie
                    var serie = chart.GetSerie<Radar>();
                    //添加数据到合适维度
                    
                    serie.AddData(doubleList);
                    
                    serie.AddData(ListRandom(doubleList));
                    serie.AddData(ListRandom(doubleList));
                    
                    
                    //其他
                    var radar = chart.EnsureChartComponent<RadarCoord>();
                    radar.AddIndicatorList(nameString);
                    chart.EnsureChartComponent<Title>().text = table[i]+"RadarChart";
                }
                else if (chart is ParallelChart parallelChart)
                {
                    //获取两列数据
                    List<object> ColumnDatax = GetColumnData(table[i], 0);//名字
                    List<object> ColumnDatay = GetColumnData(table[i], 1);//对应数据
                    //将数据格式转换
                    List<string> nameString=ColumnDatax.ConvertAll(item => item.ToString());
                    List<double> doubleList = ColumnDatay.Select(item => Convert.ToDouble(item)).ToList();
                    //获取serie
                    var serie = chart.GetSerie<Parallel>();
                    serie.AddData(doubleList);
                    for (int jj = 0; jj < 20; jj++)
                    {
                        serie.AddData(ListRandom(doubleList));
                    }
                    chart.EnsureChartComponent<Title>().text = table[i]+"ParallelChart";
                }
                else if (chart is ScatterChart scatterChart)
                {
                    //获取两列数据
                    List<object> ColumnDatax = GetColumnData(table[i], 0);//名字
                    List<object> ColumnDatay = GetColumnData(table[i], 1);//对应数据
                    //将数据格式转换
                    List<string> nameString=ColumnDatax.ConvertAll(item => item.ToString());
                    List<double> doubleList = ColumnDatay.Select(item => Convert.ToDouble(item)).ToList();
                    //获取serie
                    var serie = chart.GetSerie<Scatter>();
                    //添加数据到合适维度
                    for (int pie = 0; pie < nameString.Count; pie++)
                    {
                        serie.AddXYData((double)pie,doubleList[pie],nameString[pie],pie.ToString());
                        
                        serie.AddXYData((double)pie,ListRandom(doubleList)[pie],nameString[pie],pie.ToString());
                    }
                    
                   //其他
                    chart.EnsureChartComponent<Title>().text = table[i]+"scatterChart";
                }

                chart.SetAllDirty();
            }
            else
            {
                Debug.LogError($"GameObject {XChartObj[i].name} 上没有找到 BaseChart 组件！");
                chartsComponent[i] = null;
            }
        }
        
    }


    /// <summary>
    /// 查询指定表的第n列所有数据
    /// </summary>
    /// <param name="tableName">表名称</param>
    /// <param name="columnIndex">列索引(从0开始)</param>
    /// <returns>该列的所有数据</returns>
    private List<object> GetColumnData(string tableName, int columnIndex)
    {
        var columnData = new List<object>();
        
        try
        {
            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();
                
                // 获取表的列信息，以确定第n列的列名
                string columnQuery = @"
                    SELECT column_name 
                    FROM information_schema.columns 
                    WHERE table_name = @tableName 
                    ORDER BY ordinal_position";
                
                var columnNames = new List<string>();
                using (var columnCommand = new NpgsqlCommand(columnQuery, connection))
                {
                    columnCommand.Parameters.AddWithValue("tableName", tableName);
                    using (var reader = columnCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            columnNames.Add(reader.GetString(0));
                        }
                    }
                }
                
                // 检查列索引是否有效
                if (columnIndex < 0 || columnIndex >= columnNames.Count)
                {
                    Debug.LogError($"列索引 {columnIndex} 超出范围。表 {tableName} 共有 {columnNames.Count} 列。");
                    return columnData;
                }
                
                // 查询指定列的所有数据
                string columnName = columnNames[columnIndex];
                string dataQuery = $"SELECT {columnName} FROM {tableName}";
                
                using (var dataCommand = new NpgsqlCommand(dataQuery, connection))
                {
                    using (var reader = dataCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            columnData.Add(reader.GetValue(0));
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"查询表 {tableName} 第 {columnIndex} 列数据时发生错误: {ex.Message}");
        }
        
        return columnData;
    }
    
    public static List<T> ListRandom<T>(List<T> sources)
{
    Random rd = new Random();
    List<T> result = new List<T>(sources); // 复制一份避免修改原列表
    int index = 0;
    T temp;
    for (int i = 0; i < result.Count; i++)
    {
        index = rd.Next(0, result.Count);
        if (index != i)
        {
            temp = result[i];
            result[i] = result[index];
            result[index] = temp;
        }
    }
    return result;
}

}



[System.Serializable]
public class ObjectTableMapping
{
    [Tooltip("场景中的图表对象")]
    public GameObject chartObject;
    
    [Tooltip("对应的数据库表名")]
    public string tableName;
}
// chart.ClearData()：清空图表数据（不移除Series）
// chart.RemoveData()：清除图表数据（会移除所有Serie）
// chart.AddSerie()：添加Serie
// chart.AddXAxisData()：添加X轴数据
// chart.AddData()：添加Serie数据
// chart.UpdateData()：更新Serie数据
// chart.UpdateXAxisData()：更新X轴数据
// chart.UpdateDataName()：更新Serie数据的名字
//     XCharts内部有自动刷新机制，但也是在一定条件才会触发。如果自己调用了内部组件的接口，碰到组件没有刷新，确实找不到原因的话，可以用以下两个接口强制刷新：
//
// chart.RefreshAllComponent()：刷新图表组件，会重新初始化所有组件，不建议频繁待用。
// chart.RefreshChart()：刷新图表绘制，只刷新绘制部分，不会刷新组件文本，位置等部分。
// 各个组件也可以通过SetAllDirty()只刷新自己。