using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Michsky.UI.ModernUIPack;
using UnityEngine;

public class ScrollRotateCenter : MonoBehaviour
{
    public enum dir
    {
        L,
        R,
        none,
    }
    [SerializeField] private GameObject[] prefabObj;
    //半径;z轴为水平面
    [SerializeField]private float radius;
    private bool initprefab=true;
    [SerializeField] private float rotateDuration = 0.5f; // 旋转持续时间
    [SerializeField] private HorizontalSelector HorizontalSelector;
    [SerializeField]Material turnsMat;

    private float target = 0f;
    private void Start()
    {
        RotateObj(dir.none);
        
    }
    private void RotateObj(dir dir)
    {
        Vector3 OffsetPos =new Vector3(0, 0, radius);
        float IntervalAngle = 360f / prefabObj.Length;
        if(initprefab)
        {
            for (int i = 0; i < prefabObj.Length; i++)
            {
                // 计算每个预制体的角度位置
                float currentAngle = IntervalAngle * i * Mathf.Deg2Rad;
                Vector3 offsetPos = new Vector3(
                    Mathf.Sin(currentAngle) * radius,
                    0,
                    Mathf.Cos(currentAngle) * radius
                );

                Instantiate(prefabObj[i], transform.position + offsetPos, Quaternion.identity, transform);
            }
        }
        else
        {
            switch (dir)
            {
                case dir.L:
                    transform.Rotate(0, IntervalAngle, 0);
                    break;
                case dir.R:
                    transform.Rotate(0, -IntervalAngle, 0);
                    break;
            }
            
        }
        
    }
    
    public void RotateLeft()
    {
        float IntervalAngle = 360f / prefabObj.Length;
        transform.DORotate(new Vector3(0, -IntervalAngle, 0), rotateDuration, RotateMode.WorldAxisAdd);
        HorizontalSelector.PreviousClick();
        StartCoroutine(SmoothChangeSlider(target, rotateDuration));
    }

    public void RotateRight()
    {
        float IntervalAngle = 360f / prefabObj.Length;
        transform.DORotate(new Vector3(0, IntervalAngle, 0), rotateDuration, RotateMode.WorldAxisAdd);
        HorizontalSelector.ForwardClick();
        StartCoroutine(SmoothChangeSlider(target, rotateDuration));
    }

    public void RotateNone()
    {
        RotateObj(dir.none);
    }
    IEnumerator SmoothChangeSlider(float targetValue, float duration)
    {
        float startValue = turnsMat.GetFloat("_Slider");
        float elapsedTime = 0;

        while (elapsedTime < duration)
        {
            float newValue = Mathf.Lerp(startValue, targetValue, elapsedTime / duration);
            turnsMat.SetFloat("_Slider", newValue);
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        // 确保最终值准确
        turnsMat.SetFloat("_Slider", targetValue);
        if (targetValue == 2f)
        {
            target = 0f;
        }
        else if (targetValue == 0f)
        {
            target = 2f;
        }
        
    }
}
