
using UnityEngine;

public class GetStringForCharts : MonoBehaviour
{
    public string sheetName;

    public string SN()
    {
        return sheetName;
    }
    
}
