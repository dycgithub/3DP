using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;

public class DetectionDataSheetStay : MonoBehaviour
{
    [SerializeField]private DataBaseManager DataBaseManager;
    private void OnTriggerEnter(Collider other)
    {
        GetStringForCharts g = other.GetComponent<GetStringForCharts>();
        DataBaseManager.switchTableName = g.SN();
        Debug.Log(g.SN());
        DataBaseManager.SwitchDBFrom();
    }
}
