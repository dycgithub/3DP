using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffrctControll : MonoBehaviour
{
    public ShaderInteractorHolder shaderInteractorHolder;
    public ParallelWorldScan A;
    public ParallelWorldScan B;
    
    private void Start()
    {
        
    }

    private void FixedUpdate()
    {
        if(A.isInScan || B.isInScan)
        {
            shaderInteractorHolder.shapeCutoff = A.scanRadius/20f;
            shaderInteractorHolder.shapeCutoff = B.scanRadius/20f;
        }
        
    }
}
