using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// AI 概览 Gemini
///"Utils" 是"utilities"（工具、实用程序）的缩写，常用于计算机编程中，
/// 指代包含一组通用工具类或实用功能的代码。
/// </summary>
public class Utils//工具类
{
    public static int idInt = 0;
}
