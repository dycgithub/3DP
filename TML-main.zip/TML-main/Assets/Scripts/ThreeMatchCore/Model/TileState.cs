public enum TileState
{
    None, A, B, C, D, E, F, G
}