using Unity.Mathematics;

[System.Serializable]
public struct SingleScore
{
    public float2 position;

    public int value;
}