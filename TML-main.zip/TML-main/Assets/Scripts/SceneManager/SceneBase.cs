

public abstract class SceneBase
{
    public abstract void EnterScene();
    public abstract void ExitScene();
}